{
    const buttons = document.querySelectorAll('.zabeiapp-button')
    const url = 'http://192.168.0.102:8080'

    buttons.forEach((el) => {
        el.addEventListener('click', function() {
            let overlay = document.createElement('div')
            let iframe = document.createElement('iframe')
            overlay.classList.add('zabei-overlay')
            overlay.style.position = 'fixed'
            overlay.style.top = '0'
            overlay.style.left = '0'
            overlay.style.width = '100%'
            overlay.style.height = '100%'
            overlay.style.background = 'rgba(0,0,0,.8)'
            overlay.style.display = 'flex'
            overlay.style.alignItems = 'center'
            overlay.style.justifyContent = 'center'

            iframe.setAttribute('id', 'zabei-reserved-frame')
            iframe.setAttribute('width', 320)
            iframe.setAttribute('height', 750)
            iframe.setAttribute('src', `${url}/?restaurant-id=${el.getAttribute('zabeiapp-restaurant-id')}`)
            iframe.style.borderRadius = '10px'
            iframe.style.border = 'none'

            overlay.appendChild(iframe)
            overlay.addEventListener('click', closeZabeiIframe);

            document.body.appendChild(overlay)
        })
    })

    window.addEventListener('message', event => {
        if (event.data === 'close') {
            closeZabeiIframe()
        }
    });

    function closeZabeiIframe() {
        document.querySelector('.zabei-overlay').remove()
    }
}